from setuptools import setup


setup(
    name='myaction',
    version='0.0.10',
    packages=['myaction'],
    install_requires=[],
)
