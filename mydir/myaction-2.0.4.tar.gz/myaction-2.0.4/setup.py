from setuptools import setup


setup(
    name='myaction',
    packages=['myaction'],
    install_requires=[],
)
